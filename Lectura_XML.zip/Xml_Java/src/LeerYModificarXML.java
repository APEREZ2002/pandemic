import java.io.File;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class LeerYModificarXML {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        try {
            File archivoXML = new File("parametros.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(archivoXML);

            doc.getDocumentElement().normalize();

            do {
                System.out.println("1. Ver valores");
                System.out.println("2. Sobrescribir valores");
                System.out.println("3. Salir");

                System.out.print("Ingrese una opción: ");
                String opcion = scanner.nextLine();

                switch (opcion) {
                    case "1":
                        NodeList nodeList = doc.getElementsByTagName("parametros");
                        Node node = nodeList.item(0);

                        if (node.getNodeType() == Node.ELEMENT_NODE) {
                            String numCiudadesInfectadasInicio = node.getChildNodes().item(1).getTextContent();
                            String numCuidadesInfectadasRonda = node.getChildNodes().item(3).getTextContent();
                            String numEnfermedadesActivasDerrota = node.getChildNodes().item(5).getTextContent();
                            String numBrotesDerrota = node.getChildNodes().item(7).getTextContent();

                            System.out.println("Ciudades infectadas inicio: " + numCiudadesInfectadasInicio);
                            System.out.println("Ciudades infectadas ronda: " + numCuidadesInfectadasRonda);
                            System.out.println("Enfermedades activas derrota: " + numEnfermedadesActivasDerrota);
                            System.out.println("Brotes derrota: " + numBrotesDerrota);
                        }
                        break;

                    case "2":
                        NodeList parametros = doc.getElementsByTagName("parametros");
                        Node parametro = parametros.item(0);

                        if (parametro.getNodeType() == Node.ELEMENT_NODE) {
                            System.out.print("Ingrese el número de ciudades infectadas inicio: ");
                            String numCiudadesInfectadasInicio = scanner.nextLine();
                            parametro.getChildNodes().item(1).setTextContent(numCiudadesInfectadasInicio);

                            System.out.print("Ingrese el número de ciudades infectadas ronda: ");
                            String numCuidadesInfectadasRonda = scanner.nextLine();
                            parametro.getChildNodes().item(3).setTextContent(numCuidadesInfectadasRonda);

                            System.out.print("Ingrese el número de enfermedades activas derrota: ");
                            String numEnfermedadesActivasDerrota = scanner.nextLine();
                            parametro.getChildNodes().item(5).setTextContent(numEnfermedadesActivasDerrota);

                            System.out.print("Ingrese el número de brotes derrota: ");
                            String numBrotesDerrota = scanner.nextLine();
                            parametro.getChildNodes().item(7).setTextContent(numBrotesDerrota);

                            TransformerFactory transformerFactory = TransformerFactory.newInstance();
                            Transformer transformer = transformerFactory.newTransformer();
                            DOMSource source = new DOMSource(doc);
                            StreamResult result = new StreamResult(new File("parametros.xml"));
                            transformer.transform(source, result);

                            System.out.println("Valores actualizados con éxito.");
                        }
                        break;

                    case "3":
                        salir = true;
                        break;

                    default:
                        System.out.println("Opción no válida.");
                        break;
                }
            } while (!salir);
        } catch (Exception e) {
            e.printStackTrace();
        }}
    }

